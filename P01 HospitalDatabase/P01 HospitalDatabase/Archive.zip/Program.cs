﻿using System;
using Microsoft.EntityFrameworkCore.Storage;
using P01_HospitalDatabase.Initializer;

namespace P01_HospitalDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            DatabaseInitializer.ResetDatabase();
        }
    }
}