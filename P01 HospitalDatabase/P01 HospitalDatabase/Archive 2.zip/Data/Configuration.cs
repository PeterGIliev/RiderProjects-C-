﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=localhost;Database=Hospital;User ID=sa;Password=Peter@76545759";
    }
}