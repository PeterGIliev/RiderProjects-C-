﻿namespace OOP0001DefineAClassPerson
{
    public class Person
    {
        public string name;

        public int age;
    }
}