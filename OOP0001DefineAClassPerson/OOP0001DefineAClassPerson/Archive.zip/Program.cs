﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace OOP0001DefineAClassPerson
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Type personType = typeof (Person);
            FieldInfo[] fields = personType.GetFields(BindingFlags.Public | BindingFlags.Instance);    
            Console.WriteLine(fields.Length);

            var firstPerson = new Person
            {
                name = "Pesho",

                age = 20
            };

            var secondPerson = new Person
            {
                name = "Gosho",

                age = 18
            };

            var thirdPerson = new Person
            {
                name = "Stamat",

                age = 43
            };
        }
    }
}