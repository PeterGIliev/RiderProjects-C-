﻿namespace P03_FootballBetting.Data.Models
{
    public enum GameResult
    {
        HomeTeamWin,
        
        AwayTeamWin,
        
        Draw
        
        //OK
    }
}