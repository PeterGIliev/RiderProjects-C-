﻿namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=localhost;Database=FootballBetting ;User ID=sa;Password=Peter@76545759";
    }
}