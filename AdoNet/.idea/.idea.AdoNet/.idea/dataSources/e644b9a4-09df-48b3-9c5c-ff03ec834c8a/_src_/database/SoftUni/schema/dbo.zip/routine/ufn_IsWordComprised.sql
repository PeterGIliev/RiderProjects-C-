CREATE FUNCTION ufn_IsWordComprised (@setOfLetters VARCHAR(MAX), @word VARCHAR(MAX))
  RETURNS BIT
  AS
  BEGIN
    DECLARE @length INT = len(@word);
    DECLARE @index INT = 1;

    WHILE (@index <= @length)
    BEGIN
      DECLARE @char CHAR(1) = substring(@word, @index, 1)
      IF (charindex(@char, @setOfLetters) <= 0)
        BEGIN
          RETURN 0;
        END
      SET @index = @index + 1;
    END
    RETURN 1;
  END
GO
