CREATE PROCEDURE usp_GetTownsStartingWith(@matchingWord VARCHAR(50))
AS
  SELECT
    Name
  FROM Towns
  where name LIKE @matchingWord + '%'
GO
