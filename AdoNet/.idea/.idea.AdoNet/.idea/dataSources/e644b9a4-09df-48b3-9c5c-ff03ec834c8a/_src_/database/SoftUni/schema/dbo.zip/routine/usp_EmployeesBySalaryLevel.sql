CREATE PROCEDURE usp_EmployeesBySalaryLevel (@SalaryLevel VARCHAR(50))
  AS
  SELECT
    FirstName,
    LastName
  FROM Employees
  WHERE dbo.ufn_GetSalaryLevel (Salary)= @SalaryLevel;
GO
