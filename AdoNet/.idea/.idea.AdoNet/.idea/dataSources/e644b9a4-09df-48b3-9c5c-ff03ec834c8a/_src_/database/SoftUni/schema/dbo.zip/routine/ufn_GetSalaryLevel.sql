CREATE FUNCTION ufn_GetSalaryLevel (@salary MONEY)
  RETURNS VARCHAR(50)
  AS
  BEGIN
    DECLARE @result VARCHAR(50);
    IF (@salary > 50000)
      BEGIN
        SET @result = 'High'
      END
    ELSE IF (@salary >= 30000)
      BEGIN
        SET @result = 'Average'
      END
    ELSE
      BEGIN
        SET @result = 'Low'
      END
    RETURN @result
  END
GO
