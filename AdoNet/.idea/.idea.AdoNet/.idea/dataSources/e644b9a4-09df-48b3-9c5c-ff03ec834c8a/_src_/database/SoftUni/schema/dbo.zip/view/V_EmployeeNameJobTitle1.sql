CREATE VIEW V_EmployeeNameJobTitle1 AS
SELECT FirstName + ' ' + MiddleName + ' ' + LastName AS [Full Name], JobTitle
  FROM Employees
GO
