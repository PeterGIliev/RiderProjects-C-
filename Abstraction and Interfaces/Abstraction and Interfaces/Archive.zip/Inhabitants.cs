﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Microsoft.SqlServer.Server;

namespace AbstractionandInterfaces
{
    public class Inhabitants : ICitizens, IRobots, IPet
    {
        public Inhabitants(string type, string id, string model)
        {
            this.Type = type;
            Id = id;
            Model = model;
        }

        public Inhabitants(string type, string id, string name, int age, DateTime birthdate)
        {
            this.Type = type;
            Id = id;
            Name = name;
            Age = age;
            Birthdate = birthdate;
        }

        public Inhabitants(string type, DateTime birthdate, string name)
        {
            Type = type;
            Name = name;
            Birthdate = birthdate;
        }
        
        public string Type { get; set; }
        
        public string Id { get; set; }
        
        public DateTime Birthdate { get; set; }

        public string Name { get; set; }
        
        public int Age { get; set; }
        
        public string Model { get; set; }

        public void PassCheck(List<string> years, Inhabitants inhabitant, string year)
        {
            if ((inhabitant.Type == "Citizen" || inhabitant.Type == "Pet") && inhabitant.Birthdate.ToString("yyyy") == year)
            {
                years.Add(inhabitant.Birthdate.ToString("dd/MM/yyyy"));
            }
        }
    }
}