﻿using System;

namespace AbstractionandInterfaces
{
    public interface ICitizens
    {
        string Name { get; }
        
        int Age { get; }
        
        string Id { get; }
        
        DateTime Birthdate { get; }
    }
}