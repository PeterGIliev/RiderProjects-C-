﻿namespace AbstractionandInterfaces
{
    public interface IRobots
    {
        string Model { get; }
        
        string Id { get; }
    }
}