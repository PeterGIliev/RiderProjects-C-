﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace AbstractionandInterfaces
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            var years = new List<string>();
            var inhabitants = new List<Inhabitants>();

            var input = Console.ReadLine().Split(new []{' '}, StringSplitOptions.RemoveEmptyEntries);

            while (input[input.Length -1] != "End")
            {
                if (input[0] == "Robot")
                {
                    string type = input[0];
                    string model = input[1];
                    string id = input[2];
                    
                    var inhabitant = new Inhabitants(type, id, model)
                    {
                        Type = type,
                        Id = id,
                        Model = model
                    };
                    
                    inhabitants.Add(inhabitant);
                }
                else if (input[0] == "Citizen")
                {
                    string type = input[0];
                    string name = input[1];
                    int age = int.Parse(input[2]);
                    string id = input[3];
                    DateTime birthdate = DateTime.ParseExact(input[4], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    
                    var inhabitant = new Inhabitants(type, id, name, age, birthdate)
                    {
                        Type = type,
                        Id = id,
                        Name = name,
                        Age = age,
                        Birthdate = birthdate
                    };
                    
                    inhabitants.Add(inhabitant);
                }
                else if (input[0] == "Pet")
                {
                    string type = input[0];
                    DateTime birthdate = DateTime.ParseExact(input[2], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    string name = input[1];
                    
                    var inhabitant = new Inhabitants(type, birthdate, name)
                    {
                        Type = type,
                        Name = name,
                        Birthdate = birthdate
                    };
                    
                    inhabitants.Add(inhabitant);
                }
                
                input = Console.ReadLine().Split(new []{' '}, StringSplitOptions.RemoveEmptyEntries);
            }

            var year = Console.ReadLine();

            foreach (var inh in inhabitants)
            {
                inh.PassCheck(years, inh, year);
            }

            foreach (var y in years)
            {
                Console.WriteLine(y);
            }
        }
    }
}