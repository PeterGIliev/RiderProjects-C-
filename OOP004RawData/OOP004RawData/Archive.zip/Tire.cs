﻿namespace OOP004RawData
{
    public class Tire
    {
        public double Pressure;
        public int Age;

        public Tire(double pressure, int age)
        {
            this.Pressure = pressure;
            this.Age = age;
        }
    }
}