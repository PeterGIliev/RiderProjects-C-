﻿namespace OOP004RawData
{
    public class Engine
    {
        public int EngineSpeed;
        public int EnginePower;

        public Engine(int engineSpeed, int enginePower)
        {
            this.EngineSpeed = engineSpeed;
            this.EnginePower = enginePower;
        }
    }
}