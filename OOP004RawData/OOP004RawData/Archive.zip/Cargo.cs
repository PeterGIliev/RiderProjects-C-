﻿namespace OOP004RawData
{
    public class Cargo
    {
        public int CargoWeight;
        public string CargoType;

        public Cargo(int cargoWeight, string cargoType)
        {
            this.CargoWeight = cargoWeight;
            this.CargoType = cargoType;
        }
    }
}