﻿namespace P01_BillsPaymentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString =
        @"Server=.\;Database=ProductsShop;Integrated Security=True";

    }
}